
const contenedor = document.querySelector(".contenedor");

const item = document.createElement("LI");
const item2 = document.createElement("LI");
//crea el elemento li y le da la variable item
const textDelItem = document.createTextNode("Este es un item de la lista");

item.appendChild(textDelItem);
//crea un hijo al nodo. o le inserta un hijo
//en este caso el li es el padre
//y el hola del textDelItem es el child que le insertamos

item2.textContent = "este es el segundo item de la lista";
//o item2.innerHTML = "blablabla"
//de esta forma le agregamos texto directo sin crear
//la variable y toda esa vuelta

contenedor.appendChild(item);
contenedor.appendChild(item2);
//le agregamos el <li> al div class=contenedor
//el cual ya tenia un texto creado

console.log(item);

const fragmento = document.createDocumentFragment();

for (i = 0; i < 20; i++) {
	const item1 = document.createElement("LI");
	item1.textContent = "item fragmento";
	fragmento.appendChild(item1)
}

contenedor.appendChild(fragmento)










