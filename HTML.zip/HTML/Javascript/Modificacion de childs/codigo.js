
const contenedor = document.querySelector(".contenedor");

const primerHijo = contenedor.firstChild;
//seria el espacio bacio al dar espacio entre el
//div y el h2 selecciona el espacio no el h2
//tambien existe lastChild es igual pero lo ultimo
const primerElementHijo = contenedor.firstElementChild;
//este si nos pone el h2 que es el primer
//elemento child que le pusimos al div
//lastElementChidl igual pero el ultimo elemento
const hijos = contenedor.childNodes;
//muestra todos los elementos child del div
//tambien pone los text(que son los espacios en blanco)
//la identacion que ponemos en html
//del div o de cualquer nodo en este ej es un div
const hijosElement = contenedor.children;
//devuelve solamente las etiquetas html
//si le damos children[1] indicamos el elemento
// que necesitamos y no toda la lista
//h2,h4,p,etc
console.log(primerHijo)
console.log(primerElementHijo)
console.log(hijos)
console.log(hijosElement)

hijos.forEach(hijo=> console.log(hijo))
//sirve para recorrer el "array" creado por childNodes
//no es un array xq no le podemos dar los metodos de array
//.push .shift etc

for (hijo of hijosElement){
	console.log(hijo)
}
//recorremos los children


