
const rangoEtario = document.querySelector(".rangoEtario");

rangoEtario.setAttribute("type","color")
//modifica el atributo que le indiquemos
//si no lo tenia lo "crea "

valorDelAtributo = rangoEtario.getAttribute("type");

document.write("<br>" + valorDelAtributo)
//obtenemos el valor del atributo .getAttribute("type")

rangoEtario.removeAttribute("type")
//remueve el atributo indicado