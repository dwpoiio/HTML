
let nombre = prompt("Nombre:")

alert("hola " + nombre)