frutas = ["banana", " manzana", " pera"];
//elemento:   0			 1			2

document.write(frutas);

document.write(frutas[1]);
//para mostrar el elemento que me interesa
//en este caso manzana que es el 1