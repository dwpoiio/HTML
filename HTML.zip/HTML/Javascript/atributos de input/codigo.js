
const input = document.querySelector(".inputNormal");
const inputTexto = document.querySelector(".hola");

document.write(input.className + "<br>")
//muestra la clase q le damos en html
document.write(input.value + "<br>")
//muestra el valor (con lo q viene escrito por defecto)
input.type = "file"
//lo modifica al tipo de input q querramos
input.accept = "image/png"
//indicamos que formato de archivo acepta
inputTexto.minLength = 4;
//limita la validacion de un text a un minimo 
//de caracteres como un password
//que necesita min 8 caracteres para aceptarlo
inputTexto.maxLength = 10;
//no deja escribir mas que 10 caracteres
inputTexto.placeholder = "hola papi"
//deja un texto por defecto que se elimina
//al empezar a tipiar
inputTexto.required = " "
//te obliga a rellenar al campo
//como en un formulario


