let materias = {
		fisica: ["Perez","pedro","pepe","cofla","maria"],
		quimica: ["Rodriguez","pedro", "juan","pepe"],
		matematica: ["Hernandez","pedro", "juan","pepe","cofla","maria"],
		dibujo: ["Dalto","pedro", "juan","pepe","cofla","maria"]
	}

const inscribir = (alumno, materia)=>{
	personas = materias[materia];
	if (personas.length >= 21){
		document.write(`lo siento <b>${alumno}</b>, 
		las clases de <b>${materia}</b> ya estan llenas<br>`)
	} else{
		personas.push(alumno);
		if (materia =="fisica"){
			materias = {
				fisica: personas,
				quimica: materias["quimica"],
				matematica: materias["matematica"],
				dibujo: materias["dibujo"]
			}
		}
		else if (materia =="quimica"){
			materias = {
				fisica: materias["fisica"],
				quimica: personas,
				matematica: materias["matematica"],
				dibujo: materias["dibujo"]
			}
		}
		else if (materia =="matematica"){
			materias = {
				fisica: materias["fisica"],
				quimica: materias["quimica"],
				matematica: personas,
				dibujo: materias["dibujo"]
			}
		}
		else if (materia =="dibujo"){
			materias = {
				fisica: materias["fisica"],
				quimica: materias["quimica"],
				matematica: materias["matematica"],
				dibujo: personas
			}
		}
		document.write(`Felicidades <b>${alumno}</b>!
			te has inscrito a <b>${materia}</b><br>
			${materias[materia]}<br><br>`)
	}
}

inscribir("pedrito","fisica")
inscribir("manuel","fisica")
inscribir("jose","fisica")
inscribir("coca","fisica")
inscribir("chupi","fisica")
inscribir("hola","fisica")
inscribir("josefa","fisica")
inscribir("manuela","fisica")
inscribir("ermenegildo","fisica")
inscribir("loli","fisica")
inscribir("guido","fisica")
inscribir("pedrito2","fisica")
inscribir("pedrito3","fisica")
inscribir("pedrito4","fisica")
inscribir("pedrito5","fisica")
inscribir("pedrito6","fisica")
inscribir("pedrito7","fisica")
inscribir("pedrito8","fisica")
inscribir("pedrito9","fisica")
inscribir("lola","fisica")
inscribir("pepa","fisica")
inscribir("pedrito10","fisica")
inscribir("pedrito11","fisica")
inscribir("pedrito12","fisica")
inscribir("pedrito13","fisica")
inscribir("pedrito14","fisica")
inscribir("pedrito15","fisica")
inscribir("pedrito16","fisica")
inscribir("pedrito17","fisica")
inscribir("pedrito18","fisica")
inscribir("pedrito19","fisica")
inscribir("pedrito20","fisica")
inscribir("pedrito21","fisica")
inscribir("pedrito22","fisica")
inscribir("pedrito23","fisica")
inscribir("pedrito24","fisica")












