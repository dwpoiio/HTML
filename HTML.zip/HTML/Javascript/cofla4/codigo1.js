
const obtenerInformacion = (materia) =>{
	materias = {
		fisica: ["Perez","pedro","pepe","cofla","maria"],
		quimica: ["Rodriguez","pedro", "juan","pepe"],
		matematica: ["Hernandez","pedro", "juan","pepe","cofla","maria"],
		dibujo: ["Dalto","pedro", "juan","pepe","cofla","maria"]
	}
	if (materias[materia] !== undefined){
		return [materias[materia], materia,materias];
	} else {
		return materias;
	}
}

const mostrarInformacion = (materia)=>{
	let informacion = obtenerInformacion(materia);

if (informacion !== false){
	let profesor = informacion[0][0];
	let alumnos = informacion[0];
	alumnos.shift();
	document.write(`El profesor de <b>${informacion[1]}</b>
		es: <b style="color:#f00">${profesor}</b><br>
		los alumnos son: 
	<b style="color:#00f">${alumnos}</b><br><br>`);	
}
}

const cantidadDeClases = (alumno)=>{
	let informacion = obtenerInformacion();
	let clasesPresentes = [];
	let cantidadTotal = 0;
	for(info in informacion){
		if (informacion[info].includes(alumno)){
			cantidadTotal ++;
			clasesPresentes.push(" " + info);
		}
	}
	return `<b style="color:#00f">${alumno}</b> esta en <b>${cantidadTotal} clases: </b>
	<b style="color:#050">${clasesPresentes}</b><br><br>`;
}


mostrarInformacion("fisica")
mostrarInformacion("quimica")
mostrarInformacion("matematica")
mostrarInformacion("dibujo")

document.write(cantidadDeClases("cofla"))
document.write(cantidadDeClases("maria"))
document.write(cantidadDeClases("pedro"))

