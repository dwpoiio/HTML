
let parrafo = document.getElementById("parrafo");
//selecciono el elemento
document.write(parrafo + "<br>");

let texto = document.getElementsByTagName("p");
document.write(texto[0] + "<br>");
//ponemos el elemento 0 dentro del indice
//porque devuelve todos los elementos p

let muyLento = document.querySelector(".lento");
let muyRapido = document.querySelector("#parrafo");
//seleccionamos por la clase de selectores
//como en css #para id .para la class del elemento
document.write(muyLento);
document.write(muyRapido + "<br>");

let adios = document.querySelectorAll(".hola");
//sirve para seleccionar un conjunto de nodos
document.write(adios);
document.write(adios[0]);
//tambien podemos seleccionar un solo elemento
//con el indice
