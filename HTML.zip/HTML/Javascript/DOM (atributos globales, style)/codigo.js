
const titulo = document.querySelector(".titulo")

titulo.style.color = "#f00"
titulo.style.backgroundColor = "#48e"
titulo.style.padding = "30px"
//aplico css desde js
//con el sistema (camelCase) primera en minuscula
//segundapalabra comenzando en mayuscula