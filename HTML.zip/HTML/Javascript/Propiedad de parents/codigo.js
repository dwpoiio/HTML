
const contenedor = document.querySelector(".contenedor");
const h2Antiguo = document.querySelector(".h2Antiguo");
const h4 = document.querySelector(".h4")


const parrafo = document.createElement("P").innerHTML = "Parrafo";
const h2Nuevo = document.createElement("H2");

console.log(h2Antiguo.parentElement);
//nos muestra el elemento padre 
console.log(contenedor.parentNode);
//en este caso el body
//node y element son parecidos
//la diferencia no la vimos y utilizamos element


// if (respuesta) {
// 	document.write("El elemento tiene hijos (childs)")
// } else{
// 	document.write("El elemento no tiene hijos")
// }


