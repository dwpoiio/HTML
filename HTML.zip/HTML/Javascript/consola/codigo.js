//############funciones de registro######
console.assert(5 < 4)
//lanza el error en consola si es false

console.clear()
//limpia la consola

console.error("che capo, que hiciste?")
//crea un error con la frase que le digamos

console.info("aqui estoy, si soy yo")
//mensaje de informacion
//escribe un mensaje en consola
console.log("yo otra vez")
//mensaje de depuracion
//escribe un mensaje en consola

console.table([2,23,4,5,5,66,7])
//funciona con array y crea una tabla

console.warn("cuidado, cuidado, cuidado con la bomba chita")
//crea una advertencia

console.dir([1,2,3,4,5,435,4364,5645,6])
//despliega una lista con los elementos 

console.clear()

//#############funciones de conteo############

console.count()
console.count()
console.count()
console.count()
console.count()
console.count()
//cuenta cuantas veces utilizamos determinada
//funcion o elemento
console.countReset()
console.count()
//resetea el contador

console.clear()

//############funciones de agrupacion######

console.group("Frutas")
console.log("Manzana")
console.log("Banana")
//crea un grupo en consola
//como una lista para separar
console.groupEnd()
//cerramos el grupo y seguimos con la consola
console.log("pera")

console.groupCollapsed("Animales")
//igual pero esta cerrado en la consola
//tenemos que clickearlo para verlo
//el otro ya viene abierto
console.log("Mono")
console.groupEnd()

console.clear()

//##########funciones de temporizacion#####

console.time()
//inicia un temporizador
console.log("hola")
console.log("hola")
console.timeLog()
//nos dice cuanto tiempo transcurrio
//sin cerrar el temporizador
//osea sigue contando Guillermito...
console.log("hola")
console.log("hola")
console.timeEnd()
//termina el temporizador

console.log("%caqui estoy","color:#f00;background:#050;padding:20px")
//le da formato a la consola
//vaya a saber uno para que












