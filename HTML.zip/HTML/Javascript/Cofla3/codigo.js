
class celular {
	constructor(color,peso,resolucionPantalla,resolucionCamara,ram){
		this.color = color;
		this.peso = peso;
		this.resolucionPantalla = resolucionPantalla;
		this.resolucionCamara = resolucionCamara;
		this.ram = ram;
		this.info = `Color: ${this.color}<br>
		Peso: ${this.peso}<br> 
		Resolucion pantalla: ${this.resolucionPantalla}<br>
		Resolucion camara: ${this.resolucionCamara}<br>
		Ram: ${this.ram}<br>`;
	}
	verInfo(){
		document.write("<b>" +this.info + "</b><br>");
	}
}

// class perro extends animal {
// 	constructor(especie,edad,color, raza){
// 		super(especie,edad,color);
// 		this.raza = raza;
// 	}
// 	ladrar(){
// 		alert("Guau!")
// 	}
// }

const iphone = new celular("Blanco","500 gr","19 pulgadas","10 megapixeles","16gb");
const samsung = new celular("Negro","650 gr","22 pulgadas","12 megapixeles","32gb");
const huawei = new celular("Gris","380 gr","10 pulgadas","8 megapixeles","64gb");
// const gato = new animal("gato",2,"blanco");
// const pajaro = new animal("pajaro",12,"verde");
// const perro2 = new perro("perro",10,"negro","doberman");


//perro2.verInfo();
//perro2.ladrar();
//alert("Has ganado un celular")
//alert("Eligelo el numero de la marca que deseas")
let variable = prompt("1: iphone 2: samsung 3: huawei ")

if (variable == 1) {
	 modelo = iphone;
	document.write("<h1>Has elegido un Iphone X </h1><br><br>")
}
else if (variable == 2) {
	 modelo = samsung;
	document.write("<h1>Has elegido un Samsung WY45 </h1><br><br>")
}
else if (variable == 3) {
	modelo = huawei;
	document.write("<h1>Has elegido un JuJuaJuei 98c45TuViejaEntanga92 </h1><br><br>")
}
else{
	document.write("Te dije un numero raquel. del 1 al 3, porque si pones mas no funciona el codigo ")
}

modelo.verInfo();


