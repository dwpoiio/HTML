
class celular{
	constructor(color,peso,rdp,rdc,ram){
		this.color = color;
		this.peso = peso;
		this.resolucionDePantalla = rdp;
		this.resolucionDeCamara =rdc;
		this.memoriaRam = ram;
		this.encendido = false;
	} 
	presionarBotonEncendido(){
		if (this.encendido == false) {
			alert("Celular prendido");
			this.encendido = true;
		} else{
			alert("Celular apagado");
			this.encendido = false;
		}
	}

	reiniciar(){
		if (this.encendido == true) {
			alert("Reiniciando celular");
		} else{
			alert("El celular esta apagado");
		}
	}

	tomarFoto(){
		alert(`foto tomada en una resolucion de: ${this.resolucionDeCamara}`);
	}

	grabarVideo(){
		alert(`grabando video en: ${this.resolucionDeCamara}`);
	}
	mobileInfo(){
		return `
		Color: <b>${this.color}</b><br>
		Peso: <b>${this.peso}</b><br>
		Resolucion de pantalla: <b>${this.resolucionDePantalla}</b><br>
		Resolucion de camara: <b>${this.resolucionDeCamara}</b><br>
		Memoria ram: <b>${this.memoriaRam}</b><br>
		`;
	}
}

class celularAltaGama extends celular{
	constructor(color,peso,rdp,rdc,ram,rdce){
		super(color,peso,rdp,rdc,ram);
		this.resolucionCamaraExtra = rdce; 
	}
	grabarVideoLento(){
		 alert("Estas grabando en camara lenta");
	}
	reconocimientoFacial(){
		alert("Vamos a iniciar un reconocimiento facial");
	}
	infoAltaGama(){
		return this.mobileInfo() + `Resolucion de camara extra: <b>${this.resolucionCamaraExtra} </b><br>`;
	}
};

celular1 = new celular("rojo","150gr","5'","full hd","2GB");
celular2 = new celular("blanco","250gr","7'","hd","5GB");
celular3 = new celular("negro","175gr","8'","full hd","12GB");

celular4 = new celularAltaGama("gris","200gr","7'","4k","30GB","full hd");
celular5 = new celularAltaGama("violeta","180gr","7.5'","4k","25GB","hd");

celular1.presionarBotonEncendido();
celular1.tomarFoto();
celular1.grabarVideo();
celular1.reiniciar();
celular1.presionarBotonEncendido();

document.write(`
	${celular1.mobileInfo()} <br>
	${celular2.mobileInfo()} <br>
	${celular3.mobileInfo()} <br>
	${celular4.infoAltaGama()} <br>
	${celular5.infoAltaGama()} <br>`);














