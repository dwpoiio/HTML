
 class app {
 	constructor(descargas,puntuacion,peso){
 		this.descargas = descargas;
 		this.puntuacion = puntuacion;
 		this.peso = peso;
 		this.iniciada = false;
 		this.instalada = false;
 	}
 	
 	instalar(){
 		if (this.instalada == false) {
 			this.instalada = true;
 			alert("App instalada correctamente");
 		}	
 	}
 	desinstalar(){
 		if (this.instalada == true) {
 			this.instalada = false;
 			alert("App desinstalada correctamente");
 		}	
 	}
 	abrir(){
 		if (this.iniciada == false && this.instalada == true) {
 			this.iniciada = true;
 			alert("App iniciada");
 		} else{
 			alert("Ha ocurrido un problema")
 		}
 	}
 	cerrar(){
 		if (this.iniciada == true && this.instalada == true) {
 			this.iniciada = false;
 			alert("App cerrada");
 		}	
 	}
 	appInfo(){
 		return `
 		<b>Descargas:</b> ${this.descargas}<br>
 		<b>Puntuacion:</b> ${this.puntuacion}<br>
 		<b>Peso:</b> ${this.peso}<br>
 		`
 	}
}

aplicacion = new app("16.000","5 estrellas","30mb");
aplicacion1 = new app("12.000","4.5 estrellas","40mb");
aplicacion2 = new app("13.000","4.3 estrellas","45mb");
aplicacion3 = new app("16.500","3.7 estrellas","60mb");
aplicacion4 = new app("15.500","5 estrellas","30mb");
aplicacion5 = new app("15.000","4.9 estrellas","90mb");
aplicacion6 = new app("10.000","3 estrellas","15mb");
aplicacion7 = new app("6.000","2 estrellas","10mb");

aplicacion.instalar();
aplicacion.abrir();
aplicacion.cerrar();
aplicacion.desinstalar();
aplicacion.abrir();


document.write(`
	${aplicacion.appInfo()} <br>
	${aplicacion1.appInfo()} <br>
	${aplicacion2.appInfo()} <br>
	${aplicacion3.appInfo()} <br>
	${aplicacion4.appInfo()} <br>
	${aplicacion5.appInfo()} <br>
	${aplicacion6.appInfo()} <br>
	${aplicacion7.appInfo()} <br>


	`);



