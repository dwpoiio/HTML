let nombre = prompt("tu nombre es:")

if (nombre == "guille") {
	alert("tu nombre es " + nombre);
}

else if (nombre == "pedro") {
	alert("your name is " + nombre);
}

else {
	alert("te asignamos " + nombre);
}