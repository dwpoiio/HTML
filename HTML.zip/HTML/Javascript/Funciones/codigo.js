
function saludar() {
	let pregunta = prompt("Hola Guille, como fue tu dia?");

	if (pregunta == "bien") {
	alert("me alegro");
	} else { 
	alert("que pena");
	};
}

saludar1 = function () {
	// se puede escribir asi tmb 
}

function bienvenida(){
	//alert("hola")
	return 3
	//return finaliza la funcion
}

let bien = bienvenida();

//document.write(bien)

function suma (num1, num2){
	let res = num1 + num2;
	return res
}

let resultado = suma(20,25);

document.write(resultado +"<br>")

function saludo(nombre){
	let frase = `hola ${nombre}! como estas?`
	document.write(frase);
}

saludo("pedro")
document.write("<br>")

const saludo5 = nombre5=>{
	let frase5 = `hola ${nombre5}! como estas?`
	document.write(frase5);
}

saludo5("mathias")
document.write("<br>")

const saludo6 = nombre6 => document.write("hola")

saludo6()