let pc = {
	nombre:"GuillePc",
	procesador: "Intel Core I7",
	ram: "16GB",
	espacio: "1TB"
};

document.write(pc["procesador"]);

let nombre = pc["nombre"];
let procesador = pc["procesador"];
let ram = pc["ram"];
let espacio = pc["espacio"];

frase = `El nombre de mi pc es: <b>${nombre}</b> <br>
El procesador es: <b>${procesador}</b> <br>
Tiene <b>${ram}</b> de ram <br>
Un disco de <b>${espacio}</b>`;

document.write(frase);
