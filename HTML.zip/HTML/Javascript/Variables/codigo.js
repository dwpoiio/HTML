string = "cadena de texto";
var number = 18;
//var variable para todo el codigo
let boolean = false;
//let variable para seccion, ej en una funcion
//no almacena informacion en otra parte del codigo
//por ende insume menos recursos 

let numero1, numero2 = 9, numero3 = 13; 
//varias variables con un solo let agregando coma

numero1 = 2;

let numero4 = null;
//null es nulo o vacio que no es lo mismo que undefined


let numero = 29;

numero = 23;

alert (numero4);
alert (numero); //valor undefined
alert (numero1);
alert (numero2);
alert (numero3);
alert(numero + string) // 23cadena de texto
alert(numero * string) //NaN (not a number)
//const lala //error, no se puede declarar 
//sin inicializar

const nombre = "dalto"; 
//las variables const (constantes) 
//no pueden cambiar su valor
//las definimos una vez y quedan asi en todo el codigo

nombre = "suarez"; // es un error

