

decimeAlgoPorFavor = 2

document.write(decimeAlgoPorFavor)
//primera palabra con minuscula 
//y todas las nuevas empiezasn con mayuscula

document.getElementByID('')

//getEEEEElementBBBByIIIId

