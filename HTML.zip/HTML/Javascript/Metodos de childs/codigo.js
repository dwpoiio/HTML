
const contenedor = document.querySelector(".contenedor");
const h2Antiguo = document.querySelector(".h2Antiguo");
const h4 = document.querySelector(".h4")
//seleccionamos los elementos que vamos a utilizar

const parrafo = document.createElement("P").innerHTML = "Parrafo";
const h2Nuevo = document.createElement("H2");
//creamos el elemento h2
h2Nuevo.innerHTML = "Titulo";
//le damos contenido a la etiqueta h2



contenedor.replaceChild(h2Nuevo,h2Antiguo);
//reemplaza el child viejo por el antiguo
//primero colocamos el que vamos a poner luego el q sacamos

contenedor.removeChild(h4);
//removemos el child que le indicamos

let respuesta = contenedor.hasChildNodes();
//le preguntamos si el elemento contenedor
//tiene childs, respuesta booleana
//un texto ya cuenta como child (es un nodo)

document.write(respuesta + "<br><br>")

if (respuesta) {
	document.write("El elemento tiene hijos (childs)")
} else{
	document.write("El elemento no tiene hijos")
}


