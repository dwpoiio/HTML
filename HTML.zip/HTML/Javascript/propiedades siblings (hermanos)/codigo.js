//los hermanos son los que estan en la misma linea
//en el mismo rango, digamos son todos los child que comparten
//un parent, esos son hermanos o siblings




const contenedor = document.querySelector(".contenedor");
const h2Antiguo = document.querySelector(".h2Antiguo");
const h4 = document.querySelector(".h4")


const parrafo = document.createElement("P").innerHTML = "Parrafo";
const h2Nuevo = document.createElement("H2");

console.log(h2Antiguo.nextSibling);
//muestra al siguiente hermano en este caso
//texto porque esta el espacio, 
//y muestra el nodo siguiente no el elemento
console.log(h2Antiguo.previousSibling);
//muestra el nodo anterior

console.log(h2Antiguo.nextElementSibling);
//con este si muestra el siguiente elemento
//la siguiente etiqueta html
console.log(h2Antiguo.previousElementSibling);
//muestra (elemento) la etiqueta html anterior
//en este caso null porque es la primera
console.log(h4.previousElementSibling);
//ahora si el elemento anterior a este
//es el h2 y lo muestra





//console.log(contenedor.parentNode);






