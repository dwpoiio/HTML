
saludo = "hola pedro! ";
pregunta = "como estas? ";

frase = saludo + pregunta;

document.write(frase);

numero1 = 5;
numero2 = 8;
numero3 = "hola"

resultado = " " + numero1 + " y " + numero2 + " ";
//al poner el string primero no se suman
//lo forzamos a que sume como cadena de datos 

document.write(resultado);

resultado2 = numero3.concat(numero1);
//concat sirve para concatener string con numeros

document.write(resultado2)