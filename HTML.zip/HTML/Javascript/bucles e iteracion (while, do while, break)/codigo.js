let numero = 0;
let num = 0;
let num1 = 0


while (numero < 10){
	
	numero++;
	document.write(numero + "<br>");
}

do {
	num++ ; 
	document.write(num + " ");
}

while (num < 10);
//primero ejecuto el codigo  y
// luego pregunto la condicion

document.write("<br>")

while (num1 <1000) {
	num1++;
	document.write(num1 + "<br>");
	if (num1 == 10){
		break;
	}
}
//cuando se ejecuta el break, 
//se sale del bucle

