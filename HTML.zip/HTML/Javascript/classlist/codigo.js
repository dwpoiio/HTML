
const titulo = document.querySelector(".titulo")

titulo.classList.add("grande")
//añade una class, sirve para poner en css
//colores y tamaños y modificarlos dinamicamente
//desde js con funciones etc

titulo.classList.remove("grande")
//elimina la clase a un elemento

let valor = titulo.classList.item(0)
document.write(valor + "<br>")
//item nos da el value de la class
//tenemos que indicarle la posicion q necesitemos

let valor1 = titulo.classList.contains("titulo")
document.write(valor1)
//verifica si contiene determinado str
//devuelve un valor booleano

titulo.classList.toggle("nueva")
//si tiene la clase q le indicamos la saca
//si no la tiene la agrega
//ademas nos devuelve un valor booleano
//podemos forrzarla utilizando ("nueva", true) 
//siempre la agrega o ("nueva", false) siempre la saca 

titulo.classList.replace ("nueva","vieja")
//reemplaza una clase por otra
//tambien devuelve un booleano

