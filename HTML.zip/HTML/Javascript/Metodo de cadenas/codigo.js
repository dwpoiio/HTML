
let cadena = "cadena de prueba" ;
let cadena2 = "cadena"

// resultado = cadena.concat(cadena2);
//suma cadenas, concatena

// resultado = cadena.startsWith(cadena2);
//endsWith() 
//verifica con un booleano si empieza o termina
//con la cadena de texto anterior

// resultado = cadena.includes(cadena2);
//verifica  con un booleano si en algun lugar 
//de la cadena
//contiene la cadena anterior

// resultado = cadena.indexOf("prueba");
//devuelve la posicion en que se encuentra
//la primer letra con un int
//sino la encuentra devuelve -1
//lastIndexOf() lo mismo pero devuelve
//numero donde esta la palabra por ultima vez

// resultado = cadena.padStart(20, "a");
//rellena el principio de la cadena
//hasta el numero que queramos
//con el string q le decimos
//padEnd(10, "123") lo mismo pero al final

// resultado = cadena.repeat(2);
//repite la cadena la veces q le digamos

// resultado = cadena.split(" ");
//divide la cadena cada vez q viene un espacio
//oel signo q le digamos y lo convierte n array

// resultado = cadena.substring(2,7);
//crea nueva cadena con las 
//poisiciones que le indicamos

// resultado = cadena.toLowerCase(cadena2);
//convierte todo a minuscula
//toUpperCase() todo a mayuscula
//toString() lo convierte en string

//document.write(resultado.length) nos dice
// cuantos caracteres tiene nuestro string

// resultado = cadena.trim(cadena);
//remueve los espacios del string 
//al principio y al final
//trimEnd() elimina espacios del final
//trimStart() elimina espacios del comienzo

document.write(resultado)



