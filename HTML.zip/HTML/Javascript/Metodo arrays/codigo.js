
let nombres = ["pedro", "maria", "jorge","dedo","mano","hola"];

//###########metodos transformadores########
// let resultado = nombres.pop()
//elimina el ultimo elemento del array
// y lo devuelve, lo escribe si le ponemos .write
//.shift() elimina el primer elemento del array
//y lo devuelve

// let resultado = nombres.push("juancito")
//agrega un elemento al final del array

// let resultado = nombres.reverse()
//invierte el orden de los elementos

// let resultado = nombres.unshift("juan")
//agrega elementos al comienzo del array

// let resultado = nombres.sort()
//los ordena alfabeticamente o numericamente

//let resultado = nombres.splice(1,3,"adios","verde")
//elimina los elementos seleccionados
//y luego agrega los que pedimos 
//en la posicion seleccionada
//-1 es el final del array

//##############Metodos accesores###########

// let resultado = nombres.join(" <br>elemento: ")
//lo integra y lo convierte a todo en string
//poniendo en el medio lo que le indiquemos 

// let resultado = nombres.slice(1,3)
//nos devuelve la porcion del array
//que le indicamos
//-1 es el final si tenemos muchos elementos

//tambien estan todos los metodos de cadena
//includes() tostring() indexOf() lastIndexOf()

// document.write(resultado);


nombres.forEach(function(numero) {
	document.write(numero +"<br>")
})

//forEach recibe como parametro una funcion
//transforma el parametro (en este caso numero)
//en el elemento del array en cada iteracion

resultado = nombres.filter(numero => numero.length > 4) 

document.write(resultado)

//filter funciona igual pero ademas podemos
//pasarle una condicion, este caso que
//muestre los elementos con mas de 4 caracteres

