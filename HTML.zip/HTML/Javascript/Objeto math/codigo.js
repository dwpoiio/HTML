
let numero = Math.sqrt(25);
//devuelve la raiz cuadrada
let numero1 = Math.cbrt(27);
//devuelve la raiz cubica
let numero2 = Math.max(22,1,4,6,12,240,64,90);
//devuelve el numero mas grande
let numero3 = Math.min(22,1,4,6,12,240,64,90);
//devuelve el mas chico
let numero4 = Math.random();
//devuelve un numero pseudo-aleatorio entre 0 y 1
let numero5 = Math.round(numero4 *100);
//lo redondea, lo convierte en int
let numero6 = Math.floor(numero4 *100);
//lo redondea y lo convierte en int
//hacia el menor osea 4.8 = 4
//sirve para hacer un sorteo del 0 al 99
let numero7 = Math.fround(9.7555555555555490345);
//redondea hasta 4 bit (determinados numeros)
let numero8 = Math.trunc(9.3);
//elimina los decimales
let numero9 = Math.PI;
//nos devuelve el numero pi
let numero10 = Math.SQRT1_2;
//raiz cuadrada de un medio
let numero11 = Math.SQRT2;
//raiz cuadrada de dos
let numero12 = Math.E;
//constante de euler (2.718)
let numero13 = Math.LN2;
//logaritmo natural de 2 (0.693)
let numero14 = Math.LN10;
//logaritmo natural de 10 (2.303)
let numero15 = Math.LOG2E;
//logaritmo de E con base 2 (1.443)
let numero16 = Math.LOG10E;
//logaritmo de E con base 10 (0.434)



document.write(numero12)