
const titulo = document.querySelector(".titulo");

let resultado = titulo.textContent;
let resultado1 = titulo.innerText;
document.write(resultado + "<br>")
document.write(resultado1+ "<br>")
//ambos nos devuelve el texto dentro de la etiqueta
//textContent nos devuelve todo el texto el visible
//y el style="visibility: hidden;

let resultado2 = titulo.innerHTML;
//muestra el contenido html
let resultado3 = titulo.outerHTML;
//muestra toda la etiqueta html
alert(resultado2)
alert(resultado3)

