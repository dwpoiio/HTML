
let numero11 = 23
let numero22 = 13
let texto1 = "texto 1"
let texto2 = "texto 2"

let resultado = numero11 == numero22 + " "

document.write(resultado + " ")

//operadores de comparacion
//devuelven booleanos (true or false)
// == igualidad
// != inequidad
// === identicos (iguales y el mismo tipo de dato)
// !== no identico
// > mayor que
// >= mayor o igual que
// < menor que
// <= menor o igual que


let valor1 = true;
let valor2 = true;

let resultado1 =  valor1 && valor2;

let resultado2 =  valor1 || valor2;

let resultado3 =  !valor1;

document.write(resultado1 + " ");

//operadores logicos
//acepta solo valores booleanos (true or false)
// && and: 
//true && true = true 
// true && false = false
//false && false =  false
// || or
//true && true = true 
// true && false = true
//false && false =  false
// ! not
//devuelve lo contrario al valor del resultado
//si la operacion es true devuelve false
// true = false
//false = true

numero1 = 14;
numero2= 24;

afirmacion1 = numero1 < numero2; //(true)
afirmacion2 = numero1 != numero2; //(true)

document.write((numero1 < numero2 || numero1 == numero2)+ " ");

document.write(afirmacion1 && afirmacion2 + " "); //  true

document.write(!afirmacion1); // false

num1 = 12;
num2 = 24;
num3 = 25;
num4 = 92;
num5 = 92;

op = (num1 < num2 || num2 < num3) && (!(num1 == num2) && num5 != num3);
//true  
document.write(" " + op);




