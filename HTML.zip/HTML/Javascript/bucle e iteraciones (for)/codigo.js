
for (let i = 0; i < 10; i++) {
	
	if (i == 7) {
		document.write("saltea la iteracion 7 y sigue <br>")
		continue;
		//saltea la iteracion 7 y sigue
	}
	document.write(i + "<br>")
}

document.write("##########fin######### <br>")

for (let i = 8; i >=  0; i--) {
	document.write(i + "<br>")
}

//for esta compuesto de 3 partes
//declaracion e inicializacion
//condicion
//aumento o decremento

document.write("##########fin######### <br>")

let n = 6;

for (n; n >= 0; n--) {
	document.write(n + "<br>")
}

document.write(n + "<br>")

document.write("##########fin######### <br>")

let animales = ["gato", "perro", "tortuga"];
animales.edad = 20;

for (animal in  animales) {
	document.write(animal + "<br>");
	document.write(animales[animal] + "<br>");
}

document.write("<br>")

for (animal of  animales) {
	document.write(animal + "<br>");
}

document.write("<br>##########fin######### <br><br>")

array1 = ["manuel","roberto","jose"]
array2 = ["laura", "maria", array1, " esteban"]

forLabel:
for (let array in array2) {
	 if (array == 2){
	 	for (let array of array1){
	 		continue forLabel;
	 		//salteo el elemento 2
	 		document.write(array + "<br>");

	 	}
	 } else {
	 	document.write(array2[array] + "<br>")
	 }
}








