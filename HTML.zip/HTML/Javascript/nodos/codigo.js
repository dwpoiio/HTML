
const div = document.querySelector(".div3");

console.log(div.closest(".div"));
//nos selecciona el elemento ascendente mas cercano
//el contenedor que contenga mas cercano
