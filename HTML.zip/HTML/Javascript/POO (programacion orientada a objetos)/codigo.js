
class animal {
	constructor(especie,edad,color){
		this.especie = especie;
		this.edad = edad;
		this.color = color;
		this.info = `Soy un ${this.especie}
		, tengo ${this.edad} años
		y soy de color ${this.color}`;
	}
	verInfo(){
		document.write(this.info + "<br>");
	}
}

const perro = new animal("perro",5,"rojo");
const gato = new animal("gato",2,"blanco");
const pajaro = new animal("pajaro",12,"verde");

document.write(perro + "<br>");
console.log(perro); 
//para mostrar en consola 

document.write(perro.color + "<br>");
// document.write(perro.info + "<br>");
// document.write(gato.info + "<br>");
// document.write(pajaro.info + "<br>");

perro.verInfo()
gato.verInfo()
pajaro.verInfo()






