
nombre= "Guille";
frase= `soy ${nombre} y estoy caminando`;
//`` estan arriba de tab se llaman backticks
//`string ${variable} string `
//funciona solo con backticks

document.write(frase);

titulo= `<h1>Titulo</h1>
<h3>SubTitulo</h3>`;
//con backticks puedo usar lenguaje html
//dentro de javascript

document.write(titulo);

frase2= 'soy "guille" y estoy programando';
//si necesito comillas dobles en la frase
//tengo q empezarla con comillas simples
//y viceberza

document.write(frase2);






