
let numero = 10;

numero += 5; // numero = numero + 5

document.write(numero + " ");

numero *= 2; //multiplicacion
// - resta
// / division
// ** potencia o exponencacion

document.write(numero + " ");

numero %= 4; //% es resto de la division

document.write(numero + " ");

numero1 = 10;
numero2 = 5;

resultado = numero1 + numero2;

document.write(resultado + " ");

numero1-- //decremento resta de a uno 
//en este caso va a mostrar 9
// ++incremento suma de a uno

document.write(numero1 + " ");

resultado = -numero2;
// negacion unaria (volverlo negativo)

alert(resultado + " ");
