
const titulo = document.querySelector(".titulo");
const hola = document.querySelector(".hola")

titulo.setAttribute("contentEditable", "true") 
//permite modificar el texto ya establecido
//para que el usuario desde la pagina escriba
titulo.setAttribute("dir","rtl")
//indica la direccion del texto
titulo.removeAttribute("hidden","true")
//hace desaparecer el elemento
//lo estableci en html
//y lo removi en js para poder verlo
hola.setAttribute("tabindex","1")
//tocando tabulador se mueve por el indice
//en orden numerico que le pongamos al elemento
titulo.setAttribute("title","jjajaj xd")
//al dejar el mouse encima coloca una etiqueta
//con lo que le hallamos escrito

