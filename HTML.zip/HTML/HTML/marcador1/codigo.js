var edad = 0
anos = 30
let timerID


document.write("tu edad inicial es: " + edad);
document.write('<br>'); // salto de linea
document.write(anos);
document.write('<br>'); 


timerID = setInterval(suma, 200)

function suma (){
    resultado= edad += 1
    document.write("la suma es: " + resultado+"<br>");
}

//suma()

document.write(edad);


