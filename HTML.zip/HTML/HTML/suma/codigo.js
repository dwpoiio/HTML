var num1 = 1
var num2 = 2

let btn = document.createElement("button");
btn.innerHTML = "sumar";
btn.onclick = function () {
    alert("Boton presionado");
    suma();
  };
document.body.appendChild(btn);

function suma(){
    resultado=num1+num2;
}


document.write(num1+" + "+num2+" = ")
document.write(resultado)