var score = 20
var resultado=10

document.write(score+"<br>")
// 1. Create the button
var button = document.createElement("button");
button.innerHTML = "Do Something";

// 2. Append somewhere
var body = document.getElementsByTagName("body")[0];
body.appendChild(button);

// 3. Add event handler
button.addEventListener ("click", function() {
  alert("did something");
  suma();
});

function suma(){
  resultado+=1;
}
document.write("<br>"+resultado)